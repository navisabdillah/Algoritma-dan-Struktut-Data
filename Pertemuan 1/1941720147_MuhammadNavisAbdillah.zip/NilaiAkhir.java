package jobsheetsatu;
import java.util.Scanner;
/**
 *
 * @author Navis
 */
public class NilaiAkhir {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int tgs, Uts, Uas;
        String nama;
        double na;

        System.out.println("Menghitung nilai akhir (rentang nilai 0-100)");
        System.out.println("--------------------------------------------");
        System.out.print("Nama Mahasiswa \t: ");
        nama = sc.nextLine();
        System.out.print("Nilai Tugas \t: ");
        tgs = sc.nextInt();
        if (tgs > 100 || tgs < 0) {
            System.out.println("Nilai yang dimasukkan salah");
        } else {
            System.out.print("Nilai UTS \t: ");
            Uts = sc.nextInt();
            if (Uts > 100 || Uts < 0) {
                System.out.println("Nilai yang dimasukkan salah");
            } else {
                System.out.print("Nilai UAS \t: ");
                Uas = sc.nextInt();
                if (Uas > 100 || Uas < 0) {
                    System.out.println("Nilai yang dimasukkan salah");
                } else {
                    na = (tgs * 0.2) + (Uts * 0.35) + (Uas * 0.45);
                    System.out.printf("Nilai Akhir \t: %.2f", na);
                    System.out.println();
                    System.out.println("--------------------------------------------");
                }
            }
        }

    }
}
