package jobsheetsatu;

import java.util.Scanner;

/**
 *
 * @author Navis
 */
public class Array1 {
public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int X=0,Y=0;
        int arr[] = new int[15];
        int genap[] = new int[15];
        int ganjil[] = new int[15];
        
        System.out.println("--------------------------------------");
        System.out.println("Input nilai array");
        for (int i = 0; i < 15; i++) {
            System.out.print("Masukkan nilai ke-" + (i+1) + ": ");
            arr[i] = sc.nextInt();
            if (arr[i]%2 == 0){
                genap[X] = arr[i];
                X++;
            }
            else {
                ganjil[Y] = arr[i];
                Y++;
            }
        }
        System.out.println("--------------------------------------");
        System.out.println("Array Genap");
        for (int i = 0; i < X; i++) {
            System.out.println("Nilai genap ke-" + (i+1) + ": " + genap[i]);
        }
        System.out.println("--------------------------------------");
        System.out.println("Array Ganjil");
        for (int i = 0; i < Y; i++) {
            System.out.println("Nilai ganjil ke-" + (i+1) + ": " + ganjil[i]);
        }
        System.out.println("--------------------------------------");
    }    
}
