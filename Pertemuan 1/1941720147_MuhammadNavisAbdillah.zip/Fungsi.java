package jobsheetsatu;

import java.util.Scanner;

/**
 *
 * @author Navis
 */
public class Fungsi {
       static Scanner sc = new Scanner(System.in);
    static int Pilih, Fib[];

    public static void main(String[] args) {
        menu();
        pilihmenu();
    }

    static void menu() {
        System.out.println("--------------------------------------");
        System.out.println("\tDeret Fibonacci");
        System.out.println("--------------------------------------");
        System.out.println("1. Menampilkan dengan perulangan");
        System.out.println("2. Menampilkan dengan fungsi rekursif");
        System.out.println("3. Keluar");
        System.out.println("--------------------------------------");
        System.out.print("Pilih menu : ");
        Pilih = sc.nextInt();
    }

    static void pilihmenu() {
        int a, y = 0;
        switch (Pilih) {
            case 1:
                perulangan(y);
                break;
            case 2:
                System.out.print("Masukkan jumlah deret fibonacci : ");
                a = sc.nextInt();
                for (int i = 0; i < a; i++) {
                    System.out.print(fibo(i) + " ");
                }
                System.out.println();
                menu();
                pilihmenu();
                break;
            case 3:
                System.out.println("Terimakasih telah menggunakan program ini");
                System.exit(0);
            default:
                System.out.println("Menu tidak tersedia");
        }
    }

    static void perulangan(int x) {
        System.out.print("Masukkan jumlah deret fibonacci : ");
        x = sc.nextInt();

        Fib = new int[x];

        Fib[0] = 0;
        Fib[1] = 1;

        for (int i = 2; i < x; i++) {
            Fib[i] = Fib[i - 1] + Fib[i - 2];
        }
        for (int i = 0; i < x; i++) {
            System.out.print(Fib[i] + " ");
        }
        System.out.println();
        menu();
        pilihmenu();
    }

    static int fibo(int n) {
        if (n == 0 || n == 1) {
            return (n);
        } else {
            return (fibo(n - 1) + fibo(n - 2));
        }
    }
}
